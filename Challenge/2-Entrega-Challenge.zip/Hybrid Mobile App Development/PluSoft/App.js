import React from 'react'
import {
  StyleSheet,
  Text,
  View,
  TextInput,
} from 'react-native'

class App extends React.Component{
  render() {
    return (
      <View style={ styles.container }>
        <Text 
        ellipsizeMode = 'head'
        
        selectable = { false }
        style= { styles.text }>
        BEM VINDO À PLATAFORMA PLUSOFT COLABORADOR
          </Text>

        <View style= { styles.box }>
          <Text
          style={styles.textBox}>
            Melhores FUNCIONÁRIOS
          </Text>
          <Text
          style={styles.textBox}>
            1 - Gilberto
          </Text>
          <Text
          style={styles.textBox}>
            2 - Helena
          </Text>
          <Text
          style={styles.textBox}>
            3 - Matilde
          </Text>
        </View>
        <View style= { styles.box }>
        <Text
          style={styles.textBox}>
            OBJETIVOS E METAS
          </Text>
          <Text
          style={styles.textBox}>
           Gilberto - Prospecção de clientes
          </Text>
          <Text
          style={styles.textBox}>
            Helena - Implementação de SISTEMA MOBILE
          </Text>
          <Text
          style={styles.textBox}>
            Matilde - Controle da qualidade
          </Text>
        </View>
        <View style= { styles.box }>
        <Text
          style={styles.textBox}>
            FEEDBACKS
          </Text>
          <Text
          style={styles.textBox}>
            Parabéns aos melhores funcionários...
            
          </Text>

        </View>
        <View style= { styles.box }>
          <Text
          style={styles.textBox}>
            CHAT - DÚVIDAS
          </Text>
          <TextInput
          placeholder="Digite aqui"
          />
        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({

  container : {
    backgroundColor : '#000',
    flex : 1, 
    padding : 30 
  },

  text : {
    color: '#FFF',
    fontSize : 22,
    textAlign : 'center'
  },

  box : {
    alignSelf : 'center',
    backgroundColor: '#333',
    borderRadius : 10,
    height : 100,
    marginTop : 16,
    width : 300
  },

  textBox :{
    alignItems: 'center',
    textAlign: 'center',
    marginBottom: 5,
    color: '#FFF',
    fontWeight: 'bold'
  },

  person : {
    height : 10,
    width : 20
  }
  
})

export default App